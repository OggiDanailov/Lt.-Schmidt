// var playButton = document.getElementById('play')
// var pauseButton = document.getElementById('stop')
// var audio = document.getElementsByClassName('audio')[0]
// var point = document.getElementById('point')

// var audioLength = new AudioLength();
// 		var end;
// play.addEventListener('click', function(){
// 		setTimeout(function(){
// 		var dur = audio.duration;
// 		var totalTime = dur/60
// 		var beginning = 0;
// 		var end = totalTime;
// 	}, 1000);
// })

// playButton.addEventListener('click', audioLength.playAudio )
// playButton.addEventListener('click', audioLength.movePoint )
// pauseButton.addEventListener('click', audioLength.pauseAudio)

// function AudioLength(){
// 	this.playAudio = playAudio;
// 	this.pauseAudio = pauseAudio;
// 	this.movePoint = movePoint;

// function pauseAudio(){
// 		audio.pause()
// 		};
// function playAudio(){
// 		audio.play()
// 		}

// function movePoint(){
// 		position = 12; 
//     var id = setInterval(frame, 2000);
//     function frame() {
//         if (position == end) {
//             clearInterval(id);
//         } else {
//             position++; 
//             // point.style.top = pos + 'px'; 
//             point.style.left = position + 'px'; 
//             currentPosition = point.style.left
            
//         }
//     }
// }

// }
var pButton = document.getElementById('pButton')
var audio = document.getElementsByClassName('audio')[0]
var timeline = document.getElementById('timeline')
var playhead = document.getElementById('playhead')

function playAudio(){
	if(audio.paused){
		audio.play();
		pButton.className = '';
		pButton.className = 'pause';

	}
	else{
	audio.pause();
	pButton.className = '';
	pButton.className = 'play';
	}

}

audio.addEventListener('timeupdate', showTime)

function showTime(){
	var playPercent = 100 * (audio.currentTime / audio.duration)
	playhead.style.left = playPercent + '%'
	console.log(playhead)
}

audio.addEventListener("canplaythrough", function () {
	duration = audio.duration;
}, false);


//Makes timeline clickable
timeline.addEventListener("click", function (event) {
	moveplayhead(event);
	audio.currentTime = duration * clickPercent(event);
}, false);

// returns click as decimal (.77) of the total timelineWidth
function clickPercent(event) {
    return (event.clientX - getPosition(timeline)) / timelineWidth;
}

function moveplayhead(event) {
    var newMargLeft = event.clientX - getPosition(timeline);

	if (newMargLeft === 0 ) {
		playhead.style.marginLeft = newMargLeft + "px";
	}
	if (newMargLeft === 0) {
		playhead.style.marginLeft = "0px";
	}
	if (newMargLeft === timelineWidth) {
		playhead.style.marginLeft = timelineWidth + "px";
	}
}

// getPosition
// Returns elements left position relative to top-left of viewport
function getPosition(el) {
    return el.getBoundingClientRect().left;
}








